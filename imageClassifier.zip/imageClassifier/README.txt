The attached code uses a third-party library VL_FEAT.

There are 3 scripts. 

1) First run the script "prepareData.m" which prepares the feature vectors for the images.
2) Then, train the SVM by the script "trainSvm.m" 
3) Finally test the data by "testData.m"

* Make sure you change the paths of the directories in the scripts.


